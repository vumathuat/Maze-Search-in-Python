from grid import Grid
from dijkstra import dijkstra
from astar import a_star
from bfs import bfs
from dfs import dfs
from greedy_bfs import greedy_bfs
from bidirectional_astar import bidirectional
from typing import Dict
import sys
import string

# define main


def main():
    args: Dict[str, str] = read_args()
    search_method(args["filename"], args["search-method"])

# read arguments that users put in: filename for "RobotNav.txt" and search-method for "dfs" && "astar"


def read_args() -> Dict[str, str]:
    if len(sys.argv) != 3:
        print("Usage: search [filename] [search-method]")
        exit()

    return {
        "filename": sys.argv[1],
        "search-method": sys.argv[2]
    }

# parse txt file into the program with some punctuations fixed


def search_method(filename, method):
    data = open(filename, 'r')
    read = data.readlines()
    read[2] = read[2].replace("|", ",")
    remove = string.punctuation
    remove = remove.replace("|", "")
    remove = remove.replace(",", "")
    table = str.maketrans("", "", remove)
    new_read = [w.translate(table) for w in read]
    content = []

    for line in new_read:
        if line not in content:
            content.append(line.strip().split(","))

    walls = []
    for i in range(3, len(content)):
        walls.append((int(content[i][1]), int(content[i][0])))
        if int(content[i][2]) > 1 or int(content[i][3]) > 1:
            x = int(content[i][2])
            y = int(content[i][3])
            for a in range(x):
                walls.append((int(content[i][1]), int(content[i][0])+a))
                for b in range(y):
                    walls.append((int(content[i][1])+b, int(content[i][0])+a))

    # create 2D map grid
    g = Grid(int(content[0][0]), int(content[0][1]), walls)
    start = (int(content[1][1]), int(content[1][0]))
    finish = (int(content[2][1]), int(content[2][0]))
    finish2 = (int(content[3][1]), int(content[3][0]))
    # define finish2 in whichever search you want
    print(g)

    # each search algorithm will be returned
    if method == "dfs":
        print("\nPath by Depth First Search Algorithm:")
        print(g.draw_path(dfs(g, start, finish)))
        print(g.direction(dfs(g, start, finish), start))

    elif method == "bfs":
        print("\nPath by Breadth First Search Algorithm:")
        print(g.draw_path(bfs(g, start, finish)))
        print(g.direction(bfs(g, start, finish), start))

    elif method == "gbfs":
        print("\nPath by Greedy - Best First Search Algorithm:")
        print(g.draw_path(greedy_bfs(g, start, finish)))
        print(g.direction(greedy_bfs(g, start, finish), start))

    elif method == "dijkstra":
        print("\nPath by Dijkstra's Algorithm:")
        print(g.draw_path(dijkstra(g, start, finish)))
        print(g.direction(dijkstra(g, start, finish), start))

    elif method == "astar":
        print("\nPath by A* Search Algorithm:")
        print(g.draw_path(a_star(g, start, finish)))
        print(g.direction(a_star(g, start, finish), start))

    elif method == "bidirectional-astar":
        print("\nPath by BiDirectional A* Search Algorithm:")
        print(g.draw_path(bidirectional(g, start, finish2)))
        print(g.direction(bidirectional(g, start, finish2), start))

    else:
        print("Invalid search methods !")


if __name__ == "__main__":
    main()
