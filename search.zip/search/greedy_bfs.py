# Compare to pseudocode provided in Report to understand the function of each code line

from math import inf, sqrt


def hypotenuse(x, y):
    return sqrt(x ** 2 + y ** 2)


def cost_calculate(start, finish):
    return hypotenuse(finish[0] - start[0], finish[1] - start[1])
# heuristic function


def greedy_bfs(grid, start, finish):
    nodes = grid.get_nodes()
    closed_set = []
    open_set = [start]

    prev = {node: None for node in nodes}

    g_score = {node: inf for node in nodes}
    g_score[start] = 0

    f_score = {node: inf for node in nodes}
    f_score[start] = cost_calculate(start, finish)

    while open_set:
        cells = min(open_set, key=f_score.__getitem__)
        if cells == finish:
            break

        open_set.remove(cells)
        closed_set.append(cells)

        for cell in grid.get_adjacent(cells):
            if cell in closed_set:
                continue

            if cell not in open_set:
                open_set.append(cell)

            alt_g = g_score[cells] + 1

            # f(n) = h(n)
            if alt_g < g_score[cell]:
                g_score[cell] = alt_g
                f_score[cell] = \
                    cost_calculate(cell, finish)
                prev[cell] = cells

    path = [finish]
    current = finish

    while prev[current]:
        path.append(prev[current])
        current = prev[current]

    return list(reversed(path))
