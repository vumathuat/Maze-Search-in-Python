# Compare to pseudocode provided in Report to understand the function of each code line

from astar import inf, cost_calculate


def bidirectional(grid, start, finish):
    fwd_closed_set = []
    fwd_open_set = [start]

    bwd_closed_set = []
    bwd_open_set = [finish]

    nodes = grid.get_nodes()
    fwd_prev = {node: None for node in nodes}
    bwd_prev = {node: None for node in nodes}

    fwd_g_score = {node: inf for node in nodes}
    bwd_g_score = {node: inf for node in nodes}
    fwd_g_score[start] = 0
    bwd_g_score[finish] = 0

    fwd_f_score = {node: inf for node in nodes}
    bwd_f_score = {node: inf for node in nodes}
    fwd_f_score[start] = cost_calculate(start, finish)
    bwd_f_score[start] = cost_calculate(finish, start)

    while fwd_open_set and bwd_open_set:
        fwd_open_set.sort()
        bwd_open_set.sort()
        current_fwd_cell = fwd_open_set.pop(0)
        current_bwd_cell = bwd_open_set.pop(0)

        if current_fwd_cell == current_bwd_cell:
            break

        fwd_closed_set.append(current_fwd_cell)
        bwd_closed_set.append(current_bwd_cell)

        for cell in grid.get_adjacent(current_fwd_cell):
            if cell in fwd_closed_set:
                continue

            if cell not in fwd_open_set:
                fwd_open_set.append(cell)

            alt_g = fwd_g_score[current_fwd_cell] + 1

            # f(n) = g(n) + h(n)
            if alt_g < fwd_g_score[cell]:
                fwd_g_score[cell] = alt_g
                fwd_f_score[cell] = fwd_g_score[cell] + \
                    cost_calculate(cell, finish)
                fwd_prev[cell] = current_fwd_cell

        for cell in grid.get_adjacent(current_bwd_cell):
            if cell in bwd_closed_set:
                continue

            if cell not in bwd_open_set:
                bwd_open_set.append(cell)

            alt_g = bwd_g_score[current_bwd_cell] + 1

            # f(n) = g(n) + h(n)
            if alt_g < bwd_g_score[cell]:
                bwd_g_score[cell] = alt_g
                bwd_f_score[cell] = bwd_g_score[cell] + \
                    cost_calculate(cell, start)
                bwd_prev[cell] = current_bwd_cell

    fwd_path = [finish]
    fwd_current = finish

    while fwd_prev[fwd_current]:
        fwd_path.append(fwd_prev[fwd_current])
        fwd_current = fwd_prev[fwd_current]

    path = fwd_path

    return list(reversed(path))
