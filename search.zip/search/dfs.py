# Compare to pseudocode provided in Report to understand the function of each code line

def dfs(grid, start, finish):
    nodes = grid.get_nodes()
    closed_set = []
    open_set = [start]
    # stack
    prev = {node: None for node in nodes}

    while open_set:
        cells = open_set.pop()
        if cells == finish:
            break

        closed_set.append(cells)

        for cell in grid.get_adjacent(cells):
            if cell in closed_set:
                continue

            if cell not in open_set:
                open_set.append(cell)

                prev[cell] = cells

    path = [finish]
    current = finish

    while prev[current]:
        path.append(prev[current])
        current = prev[current]

    return list(reversed(path))
