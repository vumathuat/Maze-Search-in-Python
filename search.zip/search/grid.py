from itertools import product


class Grid(object):
    # init 2D map grid
    def __init__(self, i, j, walls=[]):
        self.i = i
        self.j = j
        self.grid = [[0] * j for _ in range(i)]

        self.walls = walls

        for wall in walls:
            self.grid[wall[0]][wall[1]] = 1

    def __str__(self):
        return "\n".join("".join(x) for x in self.char_map())

    # get nodes
    def get_nodes(self):
        return [(i, j) for i, j in product(range(self.i), range(self.j)) if (i, j) not in self.walls]

    # draw 2D map grid
    def char_map(self):
        arr = [["_"] * self.j for _ in range(self.i)]

        for wall in self.walls:
            arr[wall[0]][wall[1]] = "X"

        return arr

    # get all the neighbors
    def get_adjacent(self, node):
        i = node[0]
        j = node[1]

        if i < 0 or i >= self.i or j < 0 or j >= self.j:
            raise Exception("Out of bounds")

        if self.grid[i][j] != 0:
            return []

        adjacent = []
        del_up = [(-1, 0)]
        del_left = [(0, -1)]
        del_down = [(1, 0)]
        del_right = [(0, 1)]
        for del_pos in del_up:
            if 0 <= i + del_pos[0] < self.i and 0 <= j + del_pos[1] < self.j:
                if self.grid[i + del_pos[0]][j + del_pos[1]] == 0:
                    adjacent.append((i + del_pos[0], j + del_pos[1]))
            for del_pos in del_left:
                if 0 <= i + del_pos[0] < self.i and 0 <= j + del_pos[1] < self.j:
                    if self.grid[i + del_pos[0]][j + del_pos[1]] == 0:
                        adjacent.append((i + del_pos[0], j + del_pos[1]))
                for del_pos in del_down:
                    if 0 <= i + del_pos[0] < self.i and 0 <= j + del_pos[1] < self.j:
                        if self.grid[i + del_pos[0]][j + del_pos[1]] == 0:
                            adjacent.append((i + del_pos[0], j + del_pos[1]))
                    for del_pos in del_right:
                        if 0 <= i + del_pos[0] < self.i and 0 <= j + del_pos[1] < self.j:
                            if self.grid[i + del_pos[0]][j + del_pos[1]] == 0:
                                adjacent.append(
                                    (i + del_pos[0], j + del_pos[1]))

        return adjacent

    # draw path
    def draw_path(self, path):
        arr = self.char_map()
        for node in path:
            arr[node[0]][node[1]] = "."

        return "\n".join("".join(x) for x in arr)

    # return path with specific directions: UP, DOWN, LEFT, RIGHT
    def direction(self, path, start):
        node_updown = start[0]
        node_leftright = start[1]
        arr = []

        for node in path:
            if node[0] == node_updown - 1:
                node_updown -= 1
                arr.append("UP")
            elif node[1] == node_leftright - 1:
                node_leftright -= 1
                arr.append("LEFT")
            elif node[0] == node_updown + 1:
                node_updown += 1
                arr.append("DOWN")
            elif node[1] == node_leftright + 1:
                node_leftright += 1
                arr.append("RIGHT")

        if arr == []:
            return("No Path is found to reach the destination")

        return arr
