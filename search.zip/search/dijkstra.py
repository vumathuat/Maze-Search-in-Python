# Compare to pseudocode provided in Report to understand the function of each code line

from math import inf


def dijkstra(grid, start, finish):
    nodes = grid.get_nodes()
    distance = {node: inf for node in nodes}
    prev = {node: None for node in nodes}

    distance[start] = 0

    while nodes:
        cells = min(nodes, key=distance.__getitem__)
        nodes.remove(cells)

        for cell in grid.get_adjacent(cells):
            neighbors = distance[cells] + 1
            if neighbors < distance[cell]:
                distance[cell] = neighbors
                prev[cell] = cells

    path = [finish]
    current = finish

    while prev[current]:
        path.append(prev[current])
        current = prev[current]

    return list(reversed(path))
